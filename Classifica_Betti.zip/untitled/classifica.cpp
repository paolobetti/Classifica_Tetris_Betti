#include<iostream>
#include<string>
#include"classifica.h"
using namespace std;



// Procedura per visualizzare la classifica
void visualizza(Giocatore giocatori[], int cont) {
    //verifica che la classifica non sia vuota
    if (cont == 0) {
        cout << "Classifica vuota!\n";
        return;
    }
    for (int i = 0; i < cont; i++) {
        cout << i + 1 << ". Giocatore: " << giocatori[i].nome << " - Punteggio: " << giocatori[i].punteggio << endl;
    }
}

void inserisci(Giocatore giocatori[], int &cont) {

    string nome;
    float punteggio;

    cout << "inserisci parametri\n";
    cout << "inserisci nome_ ";
    cin >> nome;
    cout << "inserisci punteggio ";
    cin >> punteggio;

    // Se la classifica ha meno di 10 giocatori, aggiungi il nuovo giocatore
    if (cont < N) {
        giocatori[cont].nome = nome;
        giocatori[cont].punteggio = punteggio;

        cont++;

    } else {
        // Se la classifica è piena, sostituisce il punteggio più basso solo se il nuovo è maggiore
        if (giocatori[cont].punteggio > giocatori[N - 1].punteggio) {
            giocatori[N-1].nome = nome;
            giocatori[N-1].punteggio = punteggio;
        }
    }

    // Ordina la classifica dal punteggio più alto al più basso
    for (int i = 0; i < cont - 1; ++i) {
        for (int j = i + 1; j < cont; ++j) {
            if (giocatori[i].punteggio < giocatori[j].punteggio) {
                Giocatore temp = giocatori[i];
                giocatori[i] = giocatori[j];
                giocatori[j] = temp;
            }
        }
    }

}