#include<iostream>
#include<string>
using namespace std;
const int N = 10;

//struct di Giocatore
struct Giocatore {
    string nome;
    int punteggio;
};

//prototipi: dichiarazione delle procedure
void visualizza(Giocatore giocatori[], int cont);
void inserisci(Giocatore giocatori[], int &cont);
//viene passato cont con riferimento cosicche le modifiche si mantengano anche nel main
