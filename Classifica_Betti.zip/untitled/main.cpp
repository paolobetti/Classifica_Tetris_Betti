#include<iostream>
#include<string>
#include"classifica.h"
using namespace std;




int main(){

    Giocatore giocatori[N];     // array di giocatori
    int menu;
    int cont=0;                 //contatore numero di giocatori

    while (true){
        cout<<"1 se vuoi visualizzare la classifica \n"
               "2 se vuoi inserire un nuovo punteggio \n"
                  "0 se vuoi uscire\n _";
        cin>>menu;

        switch(menu){

            case 1:
                visualizza(giocatori, cont);
            break;

            case 2:
                inserisci(giocatori, cont);
            break;

            default:
                cout << "wrong\n";
            break;

            case 0:
                return 0;       //esce dal programma

        }
    }
}
